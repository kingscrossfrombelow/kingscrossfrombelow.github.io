# King's Cross from Below: Jekyll Materials System

These files implement a materials substrate for the King's Cross from Below website.

## Installation

### 1. Add to `_config.yml`

Copy the contents of `_config_addition.yml` into your existing `_config.yml`:

```yaml
collections:
  materials:
    output: true
    permalink: /materials/:name/

defaults:
  - scope:
      path: ""
      type: "materials"
    values:
      layout: "material"
```

### 2. Copy files to your repo

```
_includes/chapter-materials.html  →  your-repo/_includes/
_layouts/material.html            →  your-repo/_layouts/
_pages/materials.md               →  your-repo/_pages/
_materials/                       →  your-repo/_materials/  (create this folder)
```

### 3. Add slug to chapter frontmatter

Each chapter file needs a `slug` field that matches how materials reference it:

```yaml
---
title: 01. Introduction
subtitle: Michael Edwards & Jason Katz
slug: 030-introduction
---
```

### 4. Call the include in chapter pages

In each chapter markdown file, add:

```liquid
{% include chapter-materials.html %}
```

This automatically pulls all materials whose `chapters` array includes that chapter's slug.

---

## Adding materials

Create a markdown file in `_materials/` for each document, photo, map, etc.

### Minimal frontmatter

```yaml
---
id: fig-1-3
title: York Way looking north
type: photo
date: 1984

caption: "Description of the material."
alt: "Alt text for images."

copyright: "© Copyright holder"
archive: Archive name, ref. number

chapters: [030-introduction, 060-railway-lands]

file: /assets/materials/fig-1-3-york-way.jpg
---
```

### Fields

| Field | Required | Description |
|-------|----------|-------------|
| `id` | Yes | Figure/table number (e.g., fig-1-3, doc-2-1, map-3-2) |
| `title` | Yes | Short descriptive title |
| `type` | Yes | One of: `photo`, `document`, `map`, `table`, `quote`, `line-art` |
| `date` | Yes | Year or full date |
| `caption` | Yes | Caption text (will appear in book) |
| `alt` | For images | Accessibility description |
| `copyright` | Yes | Copyright statement |
| `archive` | If applicable | Archive location and reference number |
| `chapters` | Yes | Array of chapter slugs that cite this material |
| `file` | If applicable | Path to the file in /assets/materials/ |

### Type values

- `photo` — photographs
- `document` — PDFs, planning documents, letters
- `map` — maps and plans
- `table` — tables
- `quote` — text extracts requiring permission
- `line-art` — diagrams, illustrations

---

## File organisation

```
your-repo/
├── _config.yml           (add collections config)
├── _includes/
│   └── chapter-materials.html
├── _layouts/
│   └── material.html
├── _materials/
│   ├── fig-0-1-york-way.md
│   ├── doc-0-1-planning-brief.md
│   └── ...
├── _pages/
│   └── materials.md
├── _chapters/
│   └── 030-introduction.md
└── assets/
    └── materials/
        ├── fig-0-1-york-way.jpg
        ├── doc-0-1-planning-brief.pdf
        └── ...
```

---

## How it works

1. **Materials exist independently** in `_materials/`
2. **Chapters pull their materials** via the `chapters` array in each material's frontmatter
3. **The substrate index** at `/materials/` lists everything with citational trails
4. **Each material has its own page** showing full metadata and reverse links to chapters
5. **The same material can appear in multiple chapters** — listed once, cited many times

---

## Citational trails

When a reader views a material, they see which chapters cite it. When they view a chapter, they see which materials it draws on. The substrate becomes navigable as its own territory.
