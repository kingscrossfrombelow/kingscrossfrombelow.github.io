---
id: doc-0-1
title: King's Cross Railway Lands Planning Brief
type: document
date: 1987

caption: "Camden Council planning brief establishing development parameters for the railway lands site."
alt: ""

copyright: "© London Borough of Camden"
archive: Camden Local Studies and Archives, ref. PL/KC/1987/001

chapters: [030-introduction, 090-planning-battles]

file: /assets/materials/doc-0-1-planning-brief-1987.pdf
---

This planning brief was the first formal policy document addressing the future of the railway lands. It established the framework within which subsequent community negotiations took place.
