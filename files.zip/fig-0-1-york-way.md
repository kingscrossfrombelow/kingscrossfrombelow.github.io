---
id: fig-0-1
title: York Way looking north
type: photo
date: 1984

caption: "York Way looking north from Goods Way, showing the derelict railway lands before redevelopment."
alt: "Black and white photograph of an empty street with warehouse buildings and overgrown railway sidings visible to the right."

copyright: "© Camden Local Studies and Archives"
archive: Camden Local Studies and Archives, ref. P/YW/1984/032

chapters: [030-introduction, 060-railway-lands]

file: /assets/materials/fig-0-1-york-way.jpg
---

Optional additional notes about this material can go here. This content will appear on the material's individual page below the metadata.
