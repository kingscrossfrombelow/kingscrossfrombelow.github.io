---
title: 01. Introduction
subtitle: Michael Edwards & Jason Katz
slug: 030-introduction
---

This page holds additional material, links, and discussion related to the Introduction.

{% include chapter-materials.html %}

## Links

- [King's Cross Central Limited Partnership](https://www.kingscross.co.uk/)
- [Camden Council Planning Portal](https://www.camden.gov.uk/planning)

## Discussion

Comments and additions welcome. [Edit this page on GitHub](https://github.com/kingscrossfrombelow/kingscrossfrombelow.github.io/edit/master/_chapters/000-front/030.introduction.md).
