---
layout: page
title: Materials
permalink: /materials/
description: All documents, photographs, maps, and other materials held in the substrate.
---

# Materials

All documents, photographs, maps, and other materials held in the substrate. Each item records its provenance, copyright, and the chapters in which it is cited.

---

{% assign sorted_materials = site.materials | sort: "id" %}

## Documents

{% assign docs = sorted_materials | where: "type", "document" %}
{% if docs.size > 0 %}
{% for doc in docs %}
- **{{ doc.id }}**: [{{ doc.title }}]({{ doc.url }}) ({{ doc.date }})  
  *{{ doc.copyright }}*{% if doc.archive %} — {{ doc.archive }}{% endif %}  
  Cited in: {% for ch in doc.chapters %}[{{ ch }}](/{{ ch }}.html){% unless forloop.last %}, {% endunless %}{% endfor %}
{% endfor %}
{% else %}
*No documents yet.*
{% endif %}

---

## Photographs

{% assign photos = sorted_materials | where: "type", "photo" %}
{% if photos.size > 0 %}
{% for photo in photos %}
- **{{ photo.id }}**: [{{ photo.title }}]({{ photo.url }}) ({{ photo.date }})  
  *{{ photo.copyright }}*{% if photo.archive %} — {{ photo.archive }}{% endif %}  
  Cited in: {% for ch in photo.chapters %}[{{ ch }}](/{{ ch }}.html){% unless forloop.last %}, {% endunless %}{% endfor %}
{% endfor %}
{% else %}
*No photographs yet.*
{% endif %}

---

## Maps

{% assign maps = sorted_materials | where: "type", "map" %}
{% if maps.size > 0 %}
{% for map in maps %}
- **{{ map.id }}**: [{{ map.title }}]({{ map.url }}) ({{ map.date }})  
  *{{ map.copyright }}*{% if map.archive %} — {{ map.archive }}{% endif %}  
  Cited in: {% for ch in map.chapters %}[{{ ch }}](/{{ ch }}.html){% unless forloop.last %}, {% endunless %}{% endfor %}
{% endfor %}
{% else %}
*No maps yet.*
{% endif %}

---

## Tables

{% assign tables = sorted_materials | where: "type", "table" %}
{% if tables.size > 0 %}
{% for table in tables %}
- **{{ table.id }}**: [{{ table.title }}]({{ table.url }}) ({{ table.date }})  
  *{{ table.copyright }}*{% if table.archive %} — {{ table.archive }}{% endif %}  
  Cited in: {% for ch in table.chapters %}[{{ ch }}](/{{ ch }}.html){% unless forloop.last %}, {% endunless %}{% endfor %}
{% endfor %}
{% else %}
*No tables yet.*
{% endif %}
